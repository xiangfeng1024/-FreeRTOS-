#ifndef _STARTUPTASK_H
#define _STARTUPTASK_H

#include "system.h"

void StartupTask(void);
TaskHandle_t GetLanYaHandler(void);
TaskHandle_t GetMPUHandler(void);


#endif

