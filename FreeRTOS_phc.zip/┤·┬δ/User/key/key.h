#ifndef _KEY_H
#define _KEY_H

#include "system.h"

#define KEY1      PCin(13) 

void KEY_GPIO_Init(void);
void EXTIX_Init(void);

#endif


