#ifndef _LANYA_H
#define _LANYA_H

#include "system.h"

void USART1_Init(u32 bound);
void LanYa_Init(void);

#endif


